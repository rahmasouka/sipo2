<?php

namespace App\Http\Controllers;

use App\Models\Obat;
use App\Models\Permintaan;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class DashboardController extends Controller
{
    public function index()
    {
        $breadcrumb = [
            [
                'link' => '',
                'nama' => 'Dashboard'
            ]
        ];
        $data = [
            'title' => 'Dashboard',
            'link' => 'dashboard',
            'breadcrumb' => $breadcrumb,
            'totalObat' => Obat::count(),
            'totalRequest' => Auth::guard('admin')->check() ? Permintaan::count() : Permintaan::where('pelaku_id', Auth::guard('pelaku')->user()->pelaku_id)->count(),
        ];
        return view('dashboard.index', $data);
    }
}

<footer class="content-footer footer bg-footer-theme">
    <div class="container-xxl d-flex flex-wrap justify-content-between py-2 flex-md-row flex-column">
        <div class="mb-2 mb-md-0">
            ©
            <script>
                document.write(new Date().getFullYear());
            </script>
            <a href="/" target="_blank" class="footer-link fw-medium">SIPO @Kota  Kupang</a> <a
                href="https://wa.me/<?php echo e($setting['cs-wa'] ?? ''); ?>">Hub CS
                SIPO</a>
        </div>
        <div class="d-none d-lg-inline-block">
            <a href="https://kupangkota.go.id/" class="footer-link me-4" target="_blank">kupangkota.go.id</a>
            <a href="https://sodamolekv2.kupangkota.go.id/" target="_blank" class="footer-link me-4">sodamolek
                <span class="text-danger"><sup>v2</sup></span></a>

            <a href="https://kabashoax.kupangkota.go.id/" target="_blank" class="footer-link me-4">kabas hoax</a>

            <a href="https://ppid.kupangkota.go.id/" target="_blank" class="footer-link">ppid</a>
        </div>
    </div>
</footer>
<?php /**PATH D:\Projects\sipo2\resources\views/layout/footer.blade.php ENDPATH**/ ?>
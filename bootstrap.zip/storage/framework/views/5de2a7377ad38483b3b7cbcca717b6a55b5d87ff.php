<?php if(session()->has('success')): ?>
    <script>
        Swal.fire({
            title: "Berhasil",
            text: "<?php echo e(session('success')); ?>",
            icon: "success"
        });
    </script>
<?php endif; ?>
<?php if(session()->has('error')): ?>
    <script>
        Swal.fire({
            title: "Gagal",
            text: "<?php echo e(session('error')); ?>",
            icon: "error"
        });
    </script>
<?php endif; ?>
<?php if(session()->has('confirm')): ?>
    <script>
        Swal.fire({
            title: "Are you sure?",
            text: "You won't be able to revert this!",
            icon: "warning",
            showCancelButton: true,
            confirmButtonColor: "#3085d6",
            cancelButtonColor: "#d33",
            confirmButtonText: "Yes, delete it!"
        }).then((result) => {
            if (result.isConfirmed) {
                Swal.fire({
                    title: "Deleted!",
                    text: "Your file has been deleted.",
                    icon: "success"
                });
            }
        });
    </script>
<?php endif; ?>
<?php /**PATH D:\Projects\sipo2\resources\views/component/alerts.blade.php ENDPATH**/ ?>
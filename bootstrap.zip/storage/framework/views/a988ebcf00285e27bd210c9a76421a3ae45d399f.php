
<?php $__env->startSection('content'); ?>
    <?php
        $nama = '';
        $role = '';
        $email = '';
        $telp = '';
        if (Auth::guard('admin')->check()) {
            $nama = Auth::guard('admin')->user()->nama_admin;
            $email = Auth::guard('admin')->user()->email;
            $telp = Auth::guard('admin')->user()->telp;
            $role = 'Admin';
        } else {
            $nama = Auth::guard('pelaku')->user()->nama_pelaku;
            $email = Auth::guard('pelaku')->user()->email;
            $telp = Auth::guard('pelaku')->user()->kode_pelaku;
            $role = 'Pelaku';
        }
    ?>
    <div class="container-xxl flex-grow-1 container-p-y">
        <div class="row">
            <div class="col-lg-12 mb-4 order-0">
                <div class="card">
                    <div class="d-flex align-items-end row">
                        <div class="col-sm-7">
                            <div class="card-body">
                                <h5 class="card-title text-primary">Selamat Datang, <?php echo e($nama); ?> 👋 </h5>
                                <p class="mb-4">
                                    Hari ini tanggal <?php echo e(date('d/m/Y')); ?>, selamat bekerja!
                                </p>

                                <a href="javascript:;" class="btn btn-sm btn-outline-primary">Lihat Obat</a>
                            </div>
                        </div>
                        <div class="col-sm-5 text-center text-sm-left">
                            <div class="card-body pb-0 px-0 px-md-4">
                                <img src="/assets/img/illustrations/man-with-laptop-light.png" height="140"
                                    alt="View Badge User" data-app-dark-img="illustrations/man-with-laptop-dark.png"
                                    data-app-light-img="illustrations/man-with-laptop-light.png" />
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-12 col-md-4 order-1">
                <div class="row">
                    <div class="col-lg-6 col-md-12 col-6 mb-4">
                        <div class="card">
                            <div class="card-body">
                                <div class="card-title d-flex align-items-start justify-content-between">
                                    <div class="avatar flex-shrink-0">
                                        <img src="/assets/img/icons/unicons/obat.png" alt="Credit Card" class="rounded" />
                                    </div>
                                    <div class="dropdown">
                                        <button class="btn p-0" type="button" id="cardOpt6" data-bs-toggle="dropdown"
                                            aria-haspopup="true" aria-expanded="false">
                                            <i class="bx bx-dots-vertical-rounded"></i>
                                        </button>
                                        <div class="dropdown-menu dropdown-menu-end" aria-labelledby="cardOpt6">
                                            <a class="dropdown-item" href="/obat">Lihat Selengkapnya</a>
                                        </div>
                                    </div>
                                </div>
                                <span>Total Obat</span>
                                <h3 class="card-title text-nowrap mb-1"><?php echo e($totalObat); ?></h3>
                                <small class="text-secondary fw-medium">/pcs</small>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-6 col-md-12 col-6 mb-4">
                        <div class="card">
                            <div class="card-body">
                                <div class="card-title d-flex align-items-start justify-content-between">
                                    <div class="avatar flex-shrink-0">
                                        <img src="/assets/img/icons/unicons/transaksi.png" alt="Credit Card"
                                            class="rounded" />
                                    </div>
                                    <div class="dropdown">
                                        <button class="btn p-0" type="button" id="cardOpt6" data-bs-toggle="dropdown"
                                            aria-haspopup="true" aria-expanded="false">
                                            <i class="bx bx-dots-vertical-rounded"></i>
                                        </button>
                                        <div class="dropdown-menu dropdown-menu-end" aria-labelledby="cardOpt6">
                                            <a class="dropdown-item" href="/obat">Lihat Selengkapnya</a>
                                        </div>
                                    </div>
                                </div>
                                <span>Request Obat</span>
                                <h3 class="card-title text-nowrap mb-1"><?php echo e($totalRequest); ?></h3>
                                <small class="text-secondary fw-medium">Permintaan</small>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-12 mb-4 order-0">
                    <div class="card">
                        <div class="d-flex align-items-end row">
                            <div class="col-sm-7">
                                <div class="card-body">
                                    <h5 class="card-title text-primary">Permintaan Obat </h5>
                                    <p class="mb-4">
                                        Lakukan permintaan obat dengan mudah melalui <span
                                            class="text-primary"><i><b>SIPO</b></i></span>
                                    </p>

                                    <a href="/lakukan-permintaan" class="btn btn-sm btn-primary">Lakukan Permintaan</a>
                                </div>
                            </div>
                            <div class="col-sm-5 text-center text-sm-left">
                                <div class="card-body pb-0 px-0 px-md-4">
                                    <img src="/assets/img/illustrations/request.png" height="140" alt="View Badge User"
                                        data-app-dark-img="illustrations/man-with-laptop-dark.png"
                                        data-app-light-img="illustrations/man-with-laptop-light.png" />
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>


        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.container', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Projects\sipo2\resources\views/dashboard/index.blade.php ENDPATH**/ ?>